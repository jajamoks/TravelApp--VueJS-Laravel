<div id="escape-sticky-submenu">
	<ul class="">
		<li>
			<a href="#accomodations">
				Accommodations
			</a>
		</li>
		<li>
			<a href="#rate">
				Rate
			</a>
		</li>
		<li>
			<a href="#includes">
				Includes
			</a>
		</li>
		<li>
			<a href="#itenerary">
				Sample Itinerary &amp; Menu
			</a>
		</li>
		<li>
			<a href="#testimonials">
				Testimonials
			</a>
		</li>
	</ul>
</div>
