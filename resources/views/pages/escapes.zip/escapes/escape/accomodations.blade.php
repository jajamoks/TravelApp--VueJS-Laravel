<section class="row">
	<div class="col-md-12">
		<h3 id="accomodations">Accommodations</h3>
		<p>{!! $escape->escape_type->accomodations !!}</p>
		<hr />
	</div>
</section>
