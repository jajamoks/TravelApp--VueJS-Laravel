<section class="row">
	<div class="col-md-12">
		<p>{!! $escape->escape_type->description !!}</p>
		<hr />
	</div>

</section>
