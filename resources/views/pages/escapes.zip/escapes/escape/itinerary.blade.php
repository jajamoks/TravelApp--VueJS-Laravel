<section class="row">
	<div class="col-md-12">
		<h3>Sample Itinerary &amp; Menu</h3>
		{!! $escape->escape_type->itinerary !!}
		<hr />
	</div>
</section>
