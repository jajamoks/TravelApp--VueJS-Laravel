<div class="quote-medium text-center">
	<p class="quote-content">{!! $escape->escape_type->escape_testimonials['content'] !!}</p>
	<p class="quote-source">-- {{$escape->escape_type->escape_testimonials['name']}}</p>
	<hr />
</div>
