<li class="escape-thumbnail">
		{{$escape->escape_type->name}}
</li>
